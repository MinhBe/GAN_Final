from __future__ import annotations

import copy

import torch

import sys
from pathlib import Path as _Path

sys.path.insert(0, str(_Path(__file__).resolve().parent))

from discriminator import Disc
from generator import Gen


class Rollout:
    def __init__(
        self,
        generator: Gen,
        discriminator: Disc,
        rollout_num: int = 16,
        temperature: float = 1.0,
        update_rate: float = 0.8,
    ) -> None:
        self.generator = generator
        self.beta = copy.deepcopy(generator).to(generator.device)
        self.discriminator = discriminator
        self.rollout_num = max(1, int(rollout_num))
        self.temperature = temperature
        self.update_rate = float(update_rate)
        self.update_params(hard=True)

    def update_params(self, hard: bool = False) -> None:
        with torch.no_grad():
            for beta, theta in zip(self.beta.parameters(), self.generator.parameters()):
                beta.copy_(theta) if hard else beta.mul_(self.update_rate).add_(theta, alpha=1.0 - self.update_rate)
            for beta, theta in zip(self.beta.buffers(), self.generator.buffers()):
                beta.copy_(theta)
        self.beta.eval()

    @torch.no_grad()
    def get_reward(self, sequences: torch.Tensor, mask: torch.Tensor | None = None) -> torch.Tensor:
        was_training = self.discriminator.training
        self.discriminator.eval()
        self.beta.eval()

        B, T = sequences.size()
        rewards = torch.zeros(B, T, device=sequences.device)

        for prefix_len in range(1, T):
            prefix = sequences[:, :prefix_len]
            rewards[:, prefix_len - 1] = sum(
                self.discriminator.prob_real(self.beta.rollout_from_prefix(prefix, max_len=T, temperature=self.temperature))
                for _ in range(self.rollout_num)
            ) / float(self.rollout_num)

        rewards[:, T - 1] = self.discriminator.prob_real(sequences)
        if mask is not None:
            rewards = rewards * mask.to(rewards.device)
        if was_training:
            self.discriminator.train()
        return rewards


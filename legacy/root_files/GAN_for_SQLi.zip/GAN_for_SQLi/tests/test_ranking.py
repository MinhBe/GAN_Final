from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from scripts.rank_combinations import (
    BASE_METHODS,
    FAMILIES,
    SCENARIOS,
    collect_rows,
    build_parser,
    load_cells,
    load_thresholds,
    rank_phase2a,
    rank_phase3,
    select_global_ratio,
    validity_gate,
)


def quality_row(
    method: str,
    family: str,
    scenario: str,
    ratio: str,
    quality: float,
    variant: str = "",
) -> dict[str, object]:
    retrieval = method in {"smote", "gan", "ctgan"}
    row = {
        "seed": 88,
        "method": method,
        "family": family,
        "scenario": scenario,
        "ratio": ratio,
        "variant": variant,
        "generation_kind": "retrieval" if retrieval else "direct",
        "schema_valid": True,
        "stop_reason": "completed",
        "n_generated": 100,
        "generated_count_fraction": 1.0,
        "train_reference_count": 100,
        "holdout_reference_count": 20,
        "sql_parse_rate": quality,
        "sql_structure_rate": quality,
        "family_motif_coverage": quality,
        "garbage_rate": 1.0 - quality,
        "exact_input_overlap": 1.0 if retrieval else 1.0 - quality,
        "normalized_input_overlap": 1.0 if retrieval else 1.0 - quality,
        "holdout_overlap": 1.0 - quality,
        "mean_nearest_similarity": 1.0 - quality / 2.0,
        "unique_rate": quality,
        "self_bleu": 1.0 - quality,
        "distinct_1": quality,
        "distinct_2": quality,
        "distinct_3": quality,
        "dominant_payload_share": 1.0 - quality,
        "lexical_diversity": quality,
        "unique_nearest_payload_rate": quality,
        "dominant_retrieved_payload_share": 1.0 - quality,
        "rf_macro_f1": quality,
        "rf_attack_precision": quality,
        "rf_attack_recall": quality,
        "rf_attack_f1": quality,
        "rf_balanced_accuracy": quality,
        "rf_pr_auc": quality,
        "rf_delta_macro_f1": 0.01,
        "rf_delta_attack_recall": 0.01,
    }
    return row


class RankingTests(unittest.TestCase):
    def test_retrieval_gate_does_not_reject_exact_overlap_one(self) -> None:
        row = quality_row("smote", "boolean", "A", "20", 0.8)
        valid, reasons = validity_gate(row, load_thresholds(None))
        self.assertTrue(valid, reasons)

    def test_gate_rejects_non_88_seed(self) -> None:
        row = quality_row("seqgan_master", "boolean", "A", "20", 0.8)
        row["seed"] = 42
        valid, reasons = validity_gate(row, load_thresholds(None))
        self.assertFalse(valid)
        self.assertIn("seed_mismatch:42", reasons)

    def test_phase2a_borda_selects_same_top_two_for_each_family(self) -> None:
        rows = []
        values = {"A": 0.95, "B": 0.85, "C": 0.75, "D": 0.65, "E": 0.55, "F": 0.45}
        for family in FAMILIES:
            for method in BASE_METHODS:
                for scenario in SCENARIOS:
                    rows.append(quality_row(method, family, scenario, "20", values[scenario]))
        top2, details = rank_phase2a(rows, load_thresholds(None), ratio="20")
        self.assertEqual(len(top2), 8)
        for family in FAMILIES:
            selected = [row["scenario"] for row in top2 if row["family"] == family]
            self.assertEqual(selected, ["A", "B"])
        self.assertTrue(all("combined_score" not in row for row in details))

    def test_phase2a_invalid_method_makes_scenario_ineligible(self) -> None:
        rows = []
        for method in BASE_METHODS:
            for scenario in SCENARIOS:
                row = quality_row(method, "boolean", scenario, "20", 0.8)
                if method == "ctgan" and scenario == "A":
                    row["schema_valid"] = False
                rows.append(row)
        top2, details = rank_phase2a(rows, load_thresholds(None), ratio="20", families=["boolean"])
        aggregate_a = next(row for row in details if row.get("family") == "boolean" and row.get("scenario") == "A" and "eligible" in row)
        self.assertFalse(aggregate_a["eligible"])
        self.assertNotIn("A", [row["scenario"] for row in top2])

    def test_phase2b_selects_largest_ratio_with_all_cells_viable(self) -> None:
        cells = [(family, scenario) for family in FAMILIES for scenario in ("A", "B")]
        rows = []
        for ratio in ("20", "50", "100"):
            for family, scenario in cells:
                for method in BASE_METHODS:
                    row = quality_row(method, family, scenario, ratio, 0.8)
                    if ratio == "100" and family == "error" and scenario == "B" and method == "seqgan_master":
                        row["rf_delta_attack_recall"] = -0.5
                    rows.append(row)
        selected, audit = select_global_ratio(
            rows,
            load_thresholds(None),
            cells,
            ratios=("20", "50", "100"),
        )
        self.assertEqual(selected["selected_ratio"], "50")
        self.assertEqual(selected["selected_global_ratio"], "50")
        self.assertEqual(len(audit), 3)

    def test_phase3_uses_quality_stability_and_rf_groups(self) -> None:
        cells = [("boolean", "A"), ("union", "B")]
        rows = []
        for family, scenario in cells:
            for variant, value in (("V1", 0.9), ("V2", 0.6)):
                row = quality_row("seqgan_improved", family, scenario, "50", value, variant=variant)
                row.update(
                    {
                        "generator_loss": 0.5,
                        "discriminator_loss": 0.5,
                        "reward_mean": value,
                        "reward_variance": 1.0 - value,
                        "training_collapse_rate": 1.0 - value,
                        "gradient_norm": 1.0 - value / 2.0,
                        "training_time": 2.0 - value,
                    }
                )
                rows.append(row)
        ranked, details = rank_phase3(rows, load_thresholds(None), cells, "50", ("V1", "V2"))
        self.assertEqual(ranked[0]["variant"], "V1")
        self.assertEqual(ranked[0]["rank"], 1)
        self.assertTrue(ranked[0]["eligible"])
        self.assertEqual(len(details), 4)

    def test_recursive_discovery_reads_metadata_and_nested_rf(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            run_dir = Path(directory) / "phase3" / "seqgan_improved" / "boolean" / "A" / "R50" / "V1"
            rf_dir = run_dir / "rf"
            rf_dir.mkdir(parents=True)
            quality = quality_row("seqgan_improved", "boolean", "A", "50", 0.8, variant="V1")
            (run_dir / "quality_metrics.json").write_text(json.dumps(quality), encoding="utf-8")
            metadata = {
                "variant": "V1",
                "generator_loss": 0.4,
                "discriminator_loss": 0.5,
                "reward_mean": 0.7,
                "reward_variance": 0.1,
                "gradient_norm": 0.2,
                "training_time": 12.0,
            }
            (run_dir / "training_metadata.json").write_text(json.dumps(metadata), encoding="utf-8")
            baseline = {"macro_f1": 0.5, "attack_recall": 0.4}
            augmented = {
                "macro_f1": 0.7,
                "attack_precision": 0.8,
                "attack_recall": 0.6,
                "attack_f1": 0.68,
                "balanced_accuracy": 0.72,
                "pr_auc": 0.75,
            }
            (rf_dir / "baseline_metrics.json").write_text(json.dumps(baseline), encoding="utf-8")
            (rf_dir / "augmented_metrics.json").write_text(json.dumps(augmented), encoding="utf-8")
            rows = collect_rows(Path(directory))
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["variant"], "V1")
            self.assertAlmostEqual(rows[0]["rf_delta_macro_f1"], 0.2)
            self.assertAlmostEqual(rows[0]["rf_delta_attack_recall"], 0.2)
            self.assertEqual(rows[0]["training_time"], 12.0)

    def test_recursive_discovery_reads_active_rf_contract(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            run_dir = Path(directory) / "phase2b" / "gan" / "boolean" / "A" / "R50"
            run_dir.mkdir(parents=True)
            quality = quality_row("gan", "boolean", "A", "50", 0.8)
            (run_dir / "quality_metrics.json").write_text(json.dumps(quality), encoding="utf-8")
            rf = {
                "baseline": {"macro_f1": 0.5, "attack_recall": 0.4},
                "augmented": {
                    "macro_f1": 0.7,
                    "attack_precision": 0.8,
                    "attack_recall": 0.6,
                    "attack_f1": 0.68,
                    "balanced_accuracy": 0.72,
                    "pr_auc": 0.75,
                },
                "deltas": {"macro_f1": 0.2, "attack_recall": 0.2},
            }
            (run_dir / "rf_metrics.json").write_text(json.dumps(rf), encoding="utf-8")
            rows = collect_rows(Path(directory))
            self.assertEqual(len(rows), 1)
            self.assertAlmostEqual(rows[0]["rf_macro_f1"], 0.7)
            self.assertAlmostEqual(rows[0]["rf_attack_recall"], 0.6)
            self.assertAlmostEqual(rows[0]["rf_delta_macro_f1"], 0.2)
            self.assertAlmostEqual(rows[0]["rf_delta_attack_recall"], 0.2)

    def test_phase3_cli_accepts_selected_out(self) -> None:
        args = build_parser().parse_args(
            [
                "rank-phase3",
                "--results-root",
                "results",
                "--cells",
                "cells.csv",
                "--ratio",
                "50",
                "--out",
                "rank.csv",
                "--selected-out",
                "selected.json",
            ]
        )
        self.assertEqual(args.selected_out, Path("selected.json"))

    def test_cell_loader_rejects_incomplete_selection(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "cells.csv"
            path.write_text("family,scenario\nboolean,A\nboolean,B\nunion,A\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "exactly two unique scenarios"):
                load_cells(path)


if __name__ == "__main__":
    unittest.main()

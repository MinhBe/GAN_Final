from __future__ import annotations

import argparse
import csv
import tempfile
import unittest
from pathlib import Path

import torch
import pandas as pd

from models.seqgan.runtime.train import apply_baseline_defaults
from models.seqgan_improved.preprocessing.config import CONFIGS
from models.seqgan_improved.preprocessing.data import attack_payloads
from models.seqgan_improved.preprocessing.tokenizer import (
    RawCharacterTokenizer,
    SQLAwareTokenizer,
    load_tokenizer,
    make_tokenizer,
)
from models.seqgan_improved.runtime.adversarial import combine_generator_rewards
from models.seqgan_improved.runtime.epoch_logger import EpochLogger
from models.seqgan_improved.runtime.train import build_parser, decode


class RepeatingGenerator:
    def __init__(self, token_id: int, eos_id: int, pad_id: int) -> None:
        self.token_id = token_id
        self.eos_id = eos_id
        self.pad_id = pad_id

    def eval(self) -> None:
        return None

    def sample(self, batch_size: int, max_len: int, temperature: float = 1.0) -> torch.Tensor:
        row = [self.token_id, self.eos_id] + [self.pad_id] * max(0, max_len - 2)
        return torch.tensor([row] * batch_size, dtype=torch.long)


class SeqGANTokenizerTests(unittest.TestCase):
    def test_raw_character_round_trip_is_lossless(self) -> None:
        payload = "  <PAD>' OR 1=1 --  \t"
        tokenizer = RawCharacterTokenizer().build_vocab([payload])
        encoded = tokenizer.encode_for_lm(payload, max_len=100)
        self.assertEqual(tokenizer.decode(encoded), payload)
        self.assertEqual(tokenizer.tokenizer_mode, "raw_character")

    def test_sql_aware_round_trip_is_lossless_and_atomic(self) -> None:
        payload = "' OR 1=1 UNION SELECT sleep(5)-- tail  "
        tokenizer = SQLAwareTokenizer().build_vocab([payload])
        tokens = tokenizer.tokenize(payload)
        encoded = tokenizer.encode_for_lm(payload, max_len=100)
        self.assertEqual(tokenizer.decode(encoded), payload)
        self.assertIn("A:OR", tokens)
        self.assertIn("A:UNION", tokens)
        self.assertIn("A:--", tokens)
        self.assertLess(len(tokens), len(payload))

    def test_tokenizer_save_load_dispatch(self) -> None:
        payload = "1 UNION SELECT 'x'"
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "tokenizer.json"
            SQLAwareTokenizer().build_vocab([payload]).save(path)
            tokenizer = load_tokenizer(path)
            self.assertIsInstance(tokenizer, SQLAwareTokenizer)
            self.assertEqual(tokenizer.decode(tokenizer.encode_for_lm(payload, 50)), payload)

    def test_tokenizer_factory_rejects_ambiguous_legacy_names(self) -> None:
        self.assertIsInstance(make_tokenizer("raw_character"), RawCharacterTokenizer)
        self.assertIsInstance(make_tokenizer("sql_aware"), SQLAwareTokenizer)
        with self.assertRaises(ValueError):
            make_tokenizer("template")


class SeqGANRewardAndOutputTests(unittest.TestCase):
    def test_reward_off_is_discriminator_only(self) -> None:
        discriminator = torch.tensor([[0.2, 0.4], [0.8, 0.6]])
        sql_structure = torch.tensor([[1.0, 1.0], [0.0, 0.0]])
        combined = combine_generator_rewards(discriminator, sql_structure, "off", 0.7)
        self.assertTrue(torch.equal(combined, discriminator))

    def test_reward_on_uses_fixed_weight(self) -> None:
        discriminator = torch.tensor([[0.2, 0.4]])
        sql_structure = torch.tensor([[1.0, 0.0]])
        combined = combine_generator_rewards(discriminator, sql_structure, "on", 0.7)
        expected = 0.7 * discriminator + 0.3 * sql_structure
        self.assertTrue(torch.allclose(combined, expected))

    def test_decode_preserves_duplicate_samples(self) -> None:
        tokenizer = RawCharacterTokenizer().build_vocab(["x"])
        generator = RepeatingGenerator(tokenizer.char2idx["x"], tokenizer.eos_id, tokenizer.pad_id)
        payloads, stats = decode(generator, tokenizer, 7, 5, 3, 1.0)
        self.assertEqual(payloads, ["x"] * 7)
        self.assertEqual(stats["generated"], 7)
        self.assertEqual(stats["unique_count"], 1)
        self.assertAlmostEqual(float(stats["collapse_rate"]), 6 / 7)


class SeqGANConfigurationTests(unittest.TestCase):
    def test_all_configs_use_seed_88(self) -> None:
        self.assertEqual(set(CONFIGS), {"seqgan_master", "seqgan_improved"})
        self.assertTrue(all(config.seed == 88 for config in CONFIGS.values()))

    def test_baseline_wrapper_locks_master_factors(self) -> None:
        args = argparse.Namespace()
        locked = apply_baseline_defaults(args)
        self.assertEqual(locked.config, "seqgan_master")
        self.assertEqual(locked.method, "seqgan_master")
        self.assertEqual(locked.tokenizer_mode, "raw_character")
        self.assertEqual(locked.generator_reward_mode, "off")
        self.assertEqual(locked.seed, 88)
        self.assertEqual(locked.max_len, 20)
        self.assertEqual(locked.g_pretrain_epochs, 120)
        self.assertEqual(locked.d_steps, 5)
        self.assertEqual(locked.d_epochs, 3)

    def test_parser_accepts_phase1_all_family(self) -> None:
        args = build_parser().parse_args(
            [
                "--dataset",
                "train.csv",
                "--holdout-ref",
                "holdout.csv",
                "--family",
                "all",
                "--scenario",
                "A",
                "--out-dir",
                "out",
            ]
        )
        self.assertEqual(args.family, "all")
        self.assertEqual(args.seed, 88)

    def test_family_specific_payload_loading_is_fail_closed(self) -> None:
        frame = pd.DataFrame(
            {
                "payload": ["' or 1=1 --", "sleep(5)"],
                "label": ["attack", "attack"],
                "payload_type": ["boolean", "time"],
            }
        )
        with self.assertRaisesRegex(ValueError, "Expected only family"):
            attack_payloads(frame, None, 88, "boolean")
        self.assertEqual(attack_payloads(frame, None, 88, "all"), ["' or 1=1 --", "sleep(5)"])

    def test_epoch_logger_emits_stability_schema(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            logger = EpochLogger(
                Path(directory),
                run_id="run",
                method="seqgan_improved",
                phase="phase3",
                family="boolean",
                scenario="A",
                ratio="20",
                variant_id="V1",
                seed=88,
                tokenizer_mode="raw_character",
                sequence_length=20,
                g_pretrain_epochs=120,
                generator_reward_mode="off",
                reward_alpha=1.0,
            )
            logger.log(
                epoch=1,
                generator_loss=1.0,
                discriminator_loss=0.5,
                discriminator_reward_mean=0.4,
                sql_structure_reward_mean=0.3,
                reward_mean=0.4,
                reward_variance=0.02,
                generator_gradient_norm=1.2,
                discriminator_gradient_norm=0.8,
                unique_rate=0.75,
                dominant_payload_share=0.25,
                tier_rates={"garbage": 0.1, "wellformed": 0.2, "injection_shaped": 0.7},
                nearest_train_ngram_overlap=0.4,
                nearest_holdout_ngram_overlap=0.2,
                epoch_time_seconds=3.0,
                snapshot_samples=["x", "x", "y"],
            )
            logger.close()
            with (Path(directory) / "epoch_metrics.csv").open(encoding="utf-8", newline="") as handle:
                row = next(csv.DictReader(handle))
            self.assertEqual(row["reward_variance"], "0.02")
            self.assertEqual(row["collapse_rate"], "0.25")
            self.assertEqual(row["generator_gradient_norm"], "1.2")


if __name__ == "__main__":
    unittest.main()

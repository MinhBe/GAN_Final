from __future__ import annotations

import csv
import io
import json
import tempfile
import unittest
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import parse_qs, urlsplit

from scripts.evaluate_waf import (
    SEED,
    build_probe_request,
    evaluate,
    select_payloads,
    validate_target,
)


class FakeResponse:
    def __init__(self, status: int, body: bytes = b"ok") -> None:
        self.status = status
        self.body = body

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        return False

    def read(self, size: int = -1) -> bytes:
        return self.body[:size] if size >= 0 else self.body

    def getcode(self) -> int:
        return self.status


class WafTargetTests(unittest.TestCase):
    def test_loopback_targets_are_allowed(self) -> None:
        targets = [
            "http://localhost:8080/",
            "http://127.0.0.1:8080/",
            "http://127.10.20.30:8080/",
            "http://[::1]:8080/",
        ]
        for target in targets:
            self.assertEqual(validate_target(target), target)

    def test_remote_targets_are_rejected_without_override(self) -> None:
        with self.assertRaises(ValueError):
            validate_target("https://example.com/probe")
        with self.assertRaises(ValueError):
            validate_target("http://8.8.8.8/")
        self.assertEqual(
            validate_target("https://example.com/probe", allow_remote=True),
            "https://example.com/probe",
        )

    def test_credentials_and_non_http_schemes_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            validate_target("file:///tmp/socket")
        with self.assertRaises(ValueError):
            validate_target("http://user:pass@127.0.0.1:8080/")


class WafProbeTests(unittest.TestCase):
    def test_get_and_post_encode_the_same_payload(self) -> None:
        payload = "' OR 1=1 --"
        get_request = build_probe_request("http://127.0.0.1:8080/check?fixed=1", payload, "GET", "payload")
        post_request = build_probe_request("http://127.0.0.1:8080/check", payload, "POST", "payload")
        get_query = parse_qs(urlsplit(get_request.full_url).query, keep_blank_values=True)
        post_query = parse_qs(post_request.data.decode("utf-8"), keep_blank_values=True)
        self.assertEqual(get_query["payload"], [payload])
        self.assertEqual(post_query["payload"], [payload])
        self.assertEqual(get_query["fixed"], ["1"])
        self.assertEqual(get_request.method, "GET")
        self.assertEqual(post_request.method, "POST")

    def test_seeded_selection_is_reproducible(self) -> None:
        payloads = [(index, str(index)) for index in range(20)]
        first = select_payloads(payloads, seed=SEED, max_payloads=7)
        second = select_payloads(payloads, seed=SEED, max_payloads=7)
        self.assertEqual(first, second)
        with self.assertRaises(ValueError):
            select_payloads(payloads, seed=SEED + 1, max_payloads=7)

    def test_evaluate_records_success_blocks_duplicates_and_outputs(self) -> None:
        captured = []

        def opener(request, timeout):
            captured.append((request.method, request.full_url, request.data, timeout))
            if request.method == "POST":
                raise HTTPError(request.full_url, 403, "Forbidden", {}, io.BytesIO(b"blocked"))
            return FakeResponse(200)

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            input_csv = root / "generated_payloads.csv"
            with input_csv.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=["label", "payload"])
                writer.writeheader()
                writer.writerows(
                    [
                        {"label": "attack", "payload": "one"},
                        {"label": "attack", "payload": "two"},
                        {"label": "attack", "payload": "two"},
                        {"label": "attack", "payload": ""},
                    ]
                )
            out_dir = root / "results"
            records, summary = evaluate(
                input_csv=input_csv,
                target_url="http://127.0.0.1:8080/probe",
                out_dir=out_dir,
                opener=opener,
            )
            self.assertEqual(len(records), 8)
            self.assertEqual(len(captured), 8)
            self.assertEqual(sum(bool(row["blocked"]) for row in records), 4)
            self.assertEqual([row["method"] for row in records], ["GET", "POST"] * 4)
            self.assertEqual(sum(row["payload"] == "two" for row in records), 4)
            self.assertEqual(summary["seed"], 88)
            self.assertEqual(summary["blocked_count"], 4)
            self.assertEqual(summary["status_counts"], {"200": 4, "403": 4})
            self.assertTrue((out_dir / "waf_probe_results.csv").exists())
            self.assertTrue((out_dir / "waf_summary.json").exists())
            saved_summary = json.loads((out_dir / "waf_summary.json").read_text(encoding="utf-8"))
            self.assertEqual(saved_summary["probe_count"], 8)
            with (out_dir / "waf_probe_results.csv").open(encoding="utf-8", newline="") as handle:
                saved_rows = list(csv.DictReader(handle))
            self.assertEqual(len(saved_rows), 8)


if __name__ == "__main__":
    unittest.main()

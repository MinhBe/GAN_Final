from __future__ import annotations

import unittest

import pandas as pd

from models.ctgan.preprocessing.features import FEATURE_COLUMNS, feature_frame
from models.ctgan.runtime.train import _retrieve_payloads


class CTGANRetrievalTests(unittest.TestCase):
    def test_generated_vectors_map_to_nearest_real_payload_in_same_family(self) -> None:
        attacks = pd.DataFrame(
            {
                "id": ["B1", "B2", "T1"],
                "label": ["attack", "attack", "attack"],
                "payload_type": ["boolean", "boolean", "time"],
                "payload": ["' or 1=1 --", "' and 9=9 --", "sleep(5)"],
            }
        )
        source_features = feature_frame(attacks["payload"])
        generated = pd.concat(
            [
                pd.DataFrame(
                    {
                        "id": ["CTGAN_000001", "CTGAN_000002"],
                        "label": ["attack", "attack"],
                        "payload_type": ["boolean", "time"],
                    }
                ),
                source_features.iloc[[0, 2]].reset_index(drop=True)[FEATURE_COLUMNS],
            ],
            axis=1,
        )
        payloads, vectors = _retrieve_payloads(attacks, source_features, generated)
        self.assertEqual(payloads["payload"].tolist(), ["' or 1=1 --", "sleep(5)"])
        self.assertEqual(payloads["retrieval_source_id"].tolist(), ["B1", "T1"])
        self.assertEqual(payloads["retrieval_distance"].tolist(), [0.0, 0.0])
        self.assertIn("retrieval_source_id", vectors.columns)
        self.assertTrue(set(FEATURE_COLUMNS).issubset(vectors.columns))


if __name__ == "__main__":
    unittest.main()

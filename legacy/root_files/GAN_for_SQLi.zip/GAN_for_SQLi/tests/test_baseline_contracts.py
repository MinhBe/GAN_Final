from __future__ import annotations

import unittest
import tempfile
from pathlib import Path

import pandas as pd

from common.dataset_schema import canonical_payload_frame
from models.gan.runtime.train import _allocate as gan_allocate
from models.smote.runtime.train import _allocate as smote_allocate


class BaselineContractTests(unittest.TestCase):
    def test_phase1_all_uses_one_training_pool(self) -> None:
        frame = pd.DataFrame({"payload_type": ["boolean", "union", "time", "error", "other"]})
        self.assertEqual(smote_allocate(frame, 17, "all"), {"all": 17})
        self.assertEqual(gan_allocate(frame, 17, "all"), {"all": 17})

    def test_family_specific_allocation_remains_scoped(self) -> None:
        frame = pd.DataFrame({"payload_type": ["boolean", "boolean"]})
        self.assertEqual(smote_allocate(frame, 7, "boolean"), {"boolean": 7})
        self.assertEqual(gan_allocate(frame, 7, "boolean"), {"boolean": 7})

    def test_canonical_loader_preserves_payload_whitespace(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "payloads.csv"
            pd.DataFrame({"label": ["attack", "attack"], "payload": ["  ' or 1=1 --  ", "NULL"], "family": ["boolean", "other"]}).to_csv(path, index=False)
            frame = canonical_payload_frame(path)
            self.assertEqual(frame.loc[0, "payload"], "  ' or 1=1 --  ")
            self.assertEqual(frame.loc[1, "payload"], "NULL")


if __name__ == "__main__":
    unittest.main()

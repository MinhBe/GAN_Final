from __future__ import annotations

import csv
import json
import tempfile
import unittest
from pathlib import Path

from common.quality_metrics import (
    SEED,
    compute_quality_metrics,
    derive_thresholds,
    inspect_payload_file,
    normalize_payload,
    self_bleu,
)


class QualityMetricTests(unittest.TestCase):
    def test_family_all_reports_structure_and_each_motif_family(self) -> None:
        payloads = [
            "' OR 1=1 --",
            "' UNION ALL SELECT username,password FROM users --",
            "'; WAITFOR DELAY '0:0:5' --",
            "' AND extractvalue(1,concat(0x7e,user())) --",
        ]
        metrics = compute_quality_metrics(
            payloads,
            method="seqgan_master",
            family="all",
            scenario="A",
            ratio="full",
            train_ref=["x"],
            holdout_ref=["y"],
        )
        self.assertEqual(metrics["seed"], 88)
        self.assertEqual(metrics["sql_parse_rate"], 1.0)
        self.assertEqual(metrics["sql_structure_rate"], 1.0)
        self.assertEqual(metrics["garbage_rate"], 0.0)
        coverage = metrics["family_motif_coverage_by_family"]
        self.assertTrue(all(coverage[family] > 0.0 for family in ("boolean", "union", "time", "error")))
        distribution = metrics["inferred_family_distribution"]
        self.assertAlmostEqual(sum(distribution.values()), 1.0)

    def test_exact_normalized_holdout_and_nearest_metrics_are_separate(self) -> None:
        generated = ["%27   OR   1=1 --", "' OR 1=1 --"]
        train = ["' or 1=1 --", "select 1"]
        holdout = ["%27   OR   1=1 --"]
        metrics = compute_quality_metrics(
            generated,
            method="seqgan_master",
            family="boolean",
            scenario="E",
            ratio=20,
            train_ref=train,
            holdout_ref=holdout,
        )
        self.assertEqual(metrics["exact_input_overlap"], 0.0)
        self.assertEqual(metrics["normalized_input_overlap"], 1.0)
        self.assertEqual(metrics["holdout_overlap"], 0.5)
        self.assertGreater(metrics["mean_nearest_similarity"], 0.9)
        self.assertIn("nearest_token_jaccard_mean", metrics)
        self.assertIn("nearest_edit_similarity_p90", metrics)
        self.assertIn("nearest_feature_cosine_median", metrics)

    def test_retrieval_fields_measure_source_coverage(self) -> None:
        generated = ["a", "a", "b", "c"]
        metrics = compute_quality_metrics(
            generated,
            method="smote",
            family="boolean",
            scenario="A",
            ratio=20,
            train_ref=["a", "b", "c"],
            holdout_ref=["z"],
        )
        self.assertEqual(metrics["generation_kind"], "retrieval")
        self.assertEqual(metrics["exact_input_overlap"], 1.0)
        self.assertEqual(metrics["unique_nearest_payload_rate"], 0.75)
        self.assertEqual(metrics["dominant_retrieved_payload_share"], 0.5)

    def test_diversity_metrics_and_self_bleu_are_deterministic(self) -> None:
        payloads = ["or 1=1", "union select 1", "sleep(5)", "extractvalue(1,2)"]
        first = compute_quality_metrics(
            payloads,
            method="seqgan_master",
            family="all",
            scenario="A",
            ratio="full",
        )
        second = compute_quality_metrics(
            payloads,
            method="seqgan_master",
            family="all",
            scenario="A",
            ratio="full",
        )
        self.assertEqual(first["self_bleu"], second["self_bleu"])
        self.assertGreater(first["distinct_1"], 0.0)
        self.assertGreater(first["distinct_2"], 0.0)
        self.assertGreater(first["distinct_3"], 0.0)
        self.assertGreater(first["lexical_diversity"], 0.0)
        self.assertEqual(self_bleu(["x"], seed=SEED), 0.0)

    def test_empty_generation_is_garbage_and_collapsed(self) -> None:
        metrics = compute_quality_metrics(
            [],
            method="seqgan_master",
            family="boolean",
            scenario="A",
            ratio=20,
        )
        self.assertEqual(metrics["n_generated"], 0)
        self.assertEqual(metrics["garbage_rate"], 1.0)
        self.assertEqual(metrics["model_collapse_rate"], 1.0)
        self.assertEqual(metrics["dominant_payload_share"], 1.0)

    def test_normalization_is_versioned_behavior(self) -> None:
        self.assertEqual(normalize_payload("%27\u00a0OR\u00a01=1"), "' or 1=1")
        self.assertEqual(normalize_payload("\u2018OR\u2019"), "'or'")

    def test_csv_inspection_preserves_exact_payload_and_filters_attack(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "payloads.csv"
            with path.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=["label", "payload"])
                writer.writeheader()
                writer.writerow({"label": "normal", "payload": " normal "})
                writer.writerow({"label": "attack", "payload": " attack "})
            payloads, valid = inspect_payload_file(path, label_filter="attack")
            self.assertTrue(valid)
            self.assertEqual(payloads, [" attack "])

    def test_threshold_calibration_is_seeded_and_method_aware(self) -> None:
        direct = compute_quality_metrics(
            ["' or 1=1 --"],
            method="seqgan_master",
            family="boolean",
            scenario="A",
            ratio="full",
            train_ref=["x"],
            holdout_ref=["y"],
        )
        retrieval = compute_quality_metrics(
            ["' or 1=1 --"],
            method="smote",
            family="boolean",
            scenario="A",
            ratio="full",
            train_ref=["' or 1=1 --"],
            holdout_ref=["y"],
        )
        thresholds = derive_thresholds([direct, retrieval], margin=0.01)
        self.assertEqual(thresholds["seed"], 88)
        self.assertEqual(thresholds["calibration_run_count"], 2)
        self.assertIn("min_unique_rate", thresholds["direct"])
        self.assertIn("min_unique_nearest_payload_rate", thresholds["retrieval"])
        json.dumps(thresholds, allow_nan=False)


if __name__ == "__main__":
    unittest.main()

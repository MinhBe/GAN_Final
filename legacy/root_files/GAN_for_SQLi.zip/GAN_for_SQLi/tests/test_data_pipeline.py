from __future__ import annotations

import copy
import csv
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from common.ingestion import Record, classify_family, normalized_payload, parse_dataset, scenario_order, split_records
from scripts.research_pipeline import RunSpec, build_matrix, load_config, run_matrix, semantic_config_digest, sha256_file, source_sha256, write_matrix


ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "configs" / "experiment_config.yaml"


class EntrypointTests(unittest.TestCase):
    def test_research_pipeline_runs_as_a_script(self) -> None:
        process = subprocess.run(
            [sys.executable, "-B", "scripts/research_pipeline.py", "--help"],
            cwd=ROOT,
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(process.returncode, 0, process.stderr)
        self.assertIn("prepare-data", process.stdout)


class DataPreparationTests(unittest.TestCase):
    def test_normalization_and_conflicts(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "fixture.csv"
            source.write_text("payload,label\nA  B,1\na b,1\nconflict,1\nCONFLICT,0\nnormal,0\n", encoding="utf-8")
            records, stats = parse_dataset(source, root / "logs")
            self.assertEqual([record.payload for record in records], ["A  B", "normal"])
            self.assertEqual(stats.normalized_duplicate_rows_removed, 1)
            self.assertEqual(stats.conflict_groups_removed, 1)
            self.assertEqual(stats.conflict_rows_removed, 2)
            self.assertEqual(normalized_payload("A  B"), normalized_payload("a b"))

    def test_split_is_reproducible_and_disjoint(self) -> None:
        records = [Record(f"p{index}", "attack", index, index, "boolean") for index in range(50)]
        first_train, first_holdout = split_records(records, 0.2, 88)
        second_train, second_holdout = split_records(records, 0.2, 88)
        self.assertEqual(first_train, second_train)
        self.assertEqual(first_holdout, second_holdout)
        self.assertFalse({record.payload for record in first_train} & {record.payload for record in first_holdout})
        self.assertEqual(len(first_train), 40)
        self.assertEqual(len(first_holdout), 10)

    def test_scenario_order_is_deterministic(self) -> None:
        pool = [Record("x" * (index + 1), "attack", index, index, "error") for index in range(30)]
        first, capacity = scenario_order(pool, "D", 88)
        second, second_capacity = scenario_order(pool, "D", 88)
        self.assertEqual(first, second)
        self.assertEqual(capacity, second_capacity)
        self.assertLess(capacity, len(pool))

    def test_full_ratio_uses_canonical_order_for_every_scenario(self) -> None:
        pool = [Record(f"p{index}", "attack", index, index, "boolean") for index in range(20)]
        expected = [record.payload for record in pool]
        for scenario in "ABCDEF":
            selected, capacity = scenario_order(pool, scenario, 88, full=True)
            self.assertEqual([record.payload for record in selected], expected)
            self.assertEqual(capacity, len(pool))

    def test_family_classifier_preserves_literals_and_decodes_obfuscation(self) -> None:
        cases = {
            "admin' or '1'='1": "boolean",
            "a' waitfor delay '0:0:10'--": "time",
            "' and extractvalue(1,concat(0x7e,version()))--": "error",
            "%27%20union%20select%201,2--": "union",
            "' uni/**/on sel/**/ect 1,2--": "union",
        }
        for payload, family in cases.items():
            with self.subTest(payload=payload):
                self.assertEqual(classify_family(payload), family)


class MatrixTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.cfg = copy.deepcopy(load_config(CONFIG))
        self.cfg["dataset"]["work_dir"] = str(self.root / "prepared")
        self.cfg["outputs"]["results_root"] = str(self.root / "results")
        (self.root / "prepared" / "splits").mkdir(parents=True)
        for family in self.cfg["families"]:
            self._write_payload(self.root / "prepared" / "splits" / f"{family}_holdout.csv")
        self._write_payload(self.root / "prepared" / "splits" / "normal_train.csv", "normal", "normal")
        self._write_payload(self.root / "prepared" / "splits" / "normal_test.csv", "normal", "normal")
        (self.root / "prepared" / "phase1").mkdir(parents=True)
        self._write_payload(self.root / "prepared" / "phase1" / "attack_train.csv")
        self._write_payload(self.root / "prepared" / "phase1" / "attack_holdout.csv")

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def _write_payload(self, path: Path, label: str = "attack", family: str = "boolean") -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=("label", "payload", "family"))
            writer.writeheader()
            writer.writerow({"label": label, "payload": "' OR 1=1 --" if label == "attack" else "/", "family": family})

    def test_phase1_and_phase2a_counts_and_seed(self) -> None:
        phase1 = build_matrix(self.cfg, "phase1")
        phase2a = build_matrix(self.cfg, "phase2a")
        self.assertEqual(len(phase1), 4)
        self.assertEqual(len(phase2a), 96)
        for row in [*phase1, *phase2a]:
            self.assertIn("--seed 88", row.train_command)
            self.assertNotIn("budget_fraction", row.train_command)
            self.assertNotIn("scale", row.train_command)

    def test_phase2b_count(self) -> None:
        rows = []
        for family in self.cfg["families"]:
            for scenario in ("A", "B"):
                for ratio in self.cfg["phase2b"]["ratios"]:
                    dataset = self.root / "prepared" / "phase2b" / family / scenario / f"R{ratio}" / "attack_train.csv"
                    self._write_payload(dataset, family=family)
                    rows.append({"family": family, "scenario": scenario, "ratio": str(ratio), "output": str(dataset), "status": "ready"})
        manifest = self.root / "prepared" / "phase2b" / "dataset_manifest.json"
        manifest.write_text(json.dumps({"rows": rows}), encoding="utf-8")
        self.assertEqual(len(build_matrix(self.cfg, "phase2b")), 224)

    def test_phase3_count_and_fractional_variants(self) -> None:
        files = []
        for family in self.cfg["families"]:
            for scenario in ("A", "B"):
                dataset = self.root / "prepared" / "frozen" / family / scenario / "attack_train.csv"
                self._write_payload(dataset, family=family)
                files.append({"family": family, "scenario": scenario, "path": str(dataset)})
        manifest = self.root / "prepared" / "frozen" / "dataset_manifest.json"
        manifest.write_text(json.dumps({"selected_global_ratio": "100", "files": files}), encoding="utf-8")
        matrix = build_matrix(self.cfg, "phase3")
        self.assertEqual(len(matrix), 64)
        for family in self.cfg["families"]:
            for scenario in ("A", "B"):
                variants = {row.variant_id for row in matrix if row.family == family and row.scenario == scenario}
                self.assertEqual(variants, {f"V{index}" for index in range(1, 9)})


class MatrixExecutionTests(unittest.TestCase):
    def test_resume_requires_matching_config_inputs_and_commands(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = root / "config.yaml"
            config.write_text("seed: 88\n", encoding="utf-8")
            config_data = load_config(config)
            dataset = root / "attack.csv"
            holdout = root / "holdout.csv"
            dataset.write_text("label,payload\nattack,a\n", encoding="utf-8")
            holdout.write_text("label,payload\nattack,b\n", encoding="utf-8")
            out = root / "run"
            out.mkdir()
            (out / "training_metadata.json").write_text("{}", encoding="utf-8")
            train_command = "unchanged-command"
            spec = RunSpec(
                phase="phase1",
                run_id="resume-test",
                method="smote",
                family="all",
                scenario="raw",
                ratio="full",
                variant_id="",
                dataset=str(dataset),
                holdout_ref=str(holdout),
                out_dir=str(out),
                data_status="ready",
                config_digest=semantic_config_digest(config_data),
                train_command=train_command,
                quality_command="",
                rf_command="",
            )
            matrix = root / "matrix.csv"
            write_matrix([spec], matrix)
            manifest = {
                "status": "completed",
                "seed": 88,
                "config_sha256": sha256_file(config),
                "source_sha256": source_sha256(),
                "inputs": {
                    "dataset": {"sha256": sha256_file(dataset)},
                    "holdout": {"sha256": sha256_file(holdout)},
                },
                "commands": {"train": train_command},
            }
            (out / "run_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            with patch("scripts.research_pipeline.run_step") as run_step:
                self.assertEqual(run_matrix(matrix, True, ("train",), True, False, config), 0)
                run_step.assert_not_called()
            dataset.write_text("label,payload\nattack,changed\n", encoding="utf-8")
            with patch("scripts.research_pipeline.run_step", return_value=0) as run_step:
                self.assertEqual(run_matrix(matrix, True, ("train",), True, False, config), 0)
                run_step.assert_called_once()

    def test_matrix_rejects_stale_semantic_config(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = root / "config.yaml"
            config.write_text("seed: 88\n", encoding="utf-8")
            spec = RunSpec(
                phase="phase1",
                run_id="stale-config",
                method="smote",
                family="all",
                scenario="raw",
                ratio="full",
                variant_id="",
                dataset=str(root / "attack.csv"),
                holdout_ref=str(root / "holdout.csv"),
                out_dir=str(root / "run"),
                data_status="ready",
                config_digest="stale",
                train_command="command",
                quality_command="",
                rf_command="",
            )
            matrix = root / "matrix.csv"
            write_matrix([spec], matrix)
            with self.assertRaisesRegex(Exception, "Matrix config digest"):
                run_matrix(matrix, False, ("train",), False, False, config)


if __name__ == "__main__":
    unittest.main()
